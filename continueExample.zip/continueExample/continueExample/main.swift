//
//  main.swift
//  continueExample
//
//  Created by anil kumar giri on 24/02/16.
//  Copyright © 2016 AKG. All rights reserved.
//

import Foundation
let work = "hello friends"
var finalWork = ""
for character in work.characters {
    switch character {
    case "a", "e", "i", "o", "u", " ":
        continue
    default:
        finalWork.append(character)
    }
}
print("The outout for finalwork is \(finalWork)")